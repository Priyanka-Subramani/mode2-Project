package com.hcl.bank.service;

import com.hcl.bank.dto.TransactionRequestDto;

public interface TransactionService 
{
	public void saveTransactionDetails(TransactionRequestDto transactionRequestDto);
	

}
