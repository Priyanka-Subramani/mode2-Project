package com.hcl.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.bank.dao.LoanRepository;
import com.hcl.bank.helper.LoanHelper;
import com.hcl.bank.model.LoanDetails;

@Service
public class LoanServiceImpl implements LoanService {

	@Autowired
	LoanRepository loanRepository;
	
	
	
	@Override
	public List<LoanDetails> getLoanbyId(double amount)
	{
		List<LoanDetails> loan=(List<LoanDetails>) loanRepository.findAll();
		double calculatedAmount=(amount*60)/100;
		List<LoanDetails> result=LoanHelper.getAmount(calculatedAmount, loan);
		return result;
	}
	
	@Override
	public double calculateSimpleInterest(LoanDetails loan)
	{
		//E = P×r×(1 + r)n/((1 + r)n - 1)
		double interest=(loan.getPrinciple()*loan.getTenure()*loan.getInterest())/100;
		return interest;
	}
	
}
