package com.hcl.bank.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class BeneficiaryDetails 
{
	@EmbeddedId
	private BeneficiaryCompositeKey key;
	private String beneficiaryName;
	
	public BeneficiaryCompositeKey getKey() {
		return key;
	}
	public void setKey(BeneficiaryCompositeKey key) {
		this.key = key;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	

}
