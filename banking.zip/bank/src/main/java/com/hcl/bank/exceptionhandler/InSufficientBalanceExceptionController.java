package com.hcl.bank.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hcl.bank.exception.CustomerNotFoundException;
import com.hcl.bank.exception.InSufficientBalanceException;

public class InSufficientBalanceExceptionController extends ResponseEntityExceptionHandler 
{
	@ExceptionHandler(InSufficientBalanceException.class)
	public ResponseEntity<Error> handleException(CustomerNotFoundException exception)
	{
		Error error=new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimeStamp(LocalDateTime.now());
		error.setSuggestion("You dont't have enough balance to do the Transaction");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}

}
