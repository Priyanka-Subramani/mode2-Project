package com.hcl.bank.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.bank.dao.AccountRepository;
import com.hcl.bank.dao.BankRepository;
import com.hcl.bank.dto.TransactionRequestDto;
import com.hcl.bank.exception.CustomerNotFoundException;
import com.hcl.bank.helper.BankHelper;
import com.hcl.bank.model.AccountDetails;
import com.hcl.bank.model.Customer;

@Service
public class AccountServiceImpl implements AccountService 
{
	@Autowired
	BankRepository bankRepository;
	
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	TransactionRequestDto transactionRequestDto;
	
	AccountDetails account=new AccountDetails();
	
	@Override
	public void saveAccount(Customer customer) 
	{
		account.setId(customer.getId());
		account.setAccountNumber(BankHelper.generateaccountNumber());
		account.setBalance(10000.0);
		accountRepository.save(account);
	}

	@Override
	public AccountDetails getAccount(long id) {
		Optional<AccountDetails> account=accountRepository.findById("ABC"+id);
		if(account.isPresent())
			return account.get();
		else
			return new AccountDetails();
	}

	@Override
	public AccountDetails getAccount(String accountNumber) 
	{
		return accountRepository.findByaccountNumber(accountNumber);
	}

	
	/* Validating the Account Number */
	@Override
	public String validateAccountNumber(TransactionRequestDto transactionRequestDto) {
		AccountDetails account=accountRepository.findByaccountNumber(transactionRequestDto.getToAccountNumber());
		if(account==null)
		{
			throw new CustomerNotFoundException("Invalid Account Number:" + transactionRequestDto.getToAccountNumber());
		}
		return "Account Number is Valid";
	}


	@Override 
	public int updateAmount(double balance) {
		
		return accountRepository.updateBalance(accountRepository.getBalance()- balance);
	}
}
