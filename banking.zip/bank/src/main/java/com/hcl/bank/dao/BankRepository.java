package com.hcl.bank.dao;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.bank.model.Customer;


@Repository
public interface BankRepository extends CrudRepository<Customer, String>
{
	@Query("select name from Customer where emailID=?1 and password=?2")
	String validateCustomer(String emailID, String password);

	
	
}
