package com.hcl.bank.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class BeneficiaryCompositeKey implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String accountNumber;
	private String beneficiaryAccountNumber;
	
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}
	public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}
	
	
	

}
