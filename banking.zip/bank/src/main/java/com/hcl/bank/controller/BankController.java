package com.hcl.bank.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.bank.model.Customer;
import com.hcl.bank.service.AccountService;
import com.hcl.bank.service.BankService;

@RestController
public class BankController 
{
	private final Logger LOGGER=LoggerFactory.getLogger(BankController.class);
	
	@Autowired
	BankService bankService;
	
	
	@Autowired
	AccountService accountService;
	
	@PostMapping("/customers")
	public void saveCustomer(@RequestBody Customer customer) {
		LOGGER.info("Welcome to the NetBanking");
		LOGGER.debug("Bank");
		bankService.saveCustomer(customer);
	}
	
	@GetMapping("/customers")
	public String validate(@RequestParam String emailID, @RequestParam String password) {
		return bankService.validate(emailID, password);
	}
	
	@GetMapping("bank/balance")
	public ResponseEntity<Integer> updateAmount(@RequestParam double balance) {
		
		int cost = accountService.updateAmount(balance);
		return new ResponseEntity<Integer>(cost,HttpStatus.OK);
	}
}
