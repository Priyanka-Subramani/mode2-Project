package com.hcl.bank.service;

import com.hcl.bank.model.Customer;

public interface BankService 
{
	public Iterable<Customer> getAllCustomerDetails();
	public void saveCustomer(Customer customer);
	public String validate(String emailID, String password);
	
}
