package com.hcl.bank.helper;

public class BankHelper 
{
	static long ID=123001;
	static long accNo=1234567890;
	public static long generatecustomerID()
	{
		return ID++;
	}
	
	public static String generateaccountNumber()
	{
		return "SBI"+accNo++;
	}

}
