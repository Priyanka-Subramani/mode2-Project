package com.hcl.bank.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.bank.dao.AccountRepository;
import com.hcl.bank.dao.BeneficiaryRepository;
import com.hcl.bank.dto.BeneficiaryRequestDto;
import com.hcl.bank.exception.BeneficiaryNotFoundException;
import com.hcl.bank.exception.CustomerNotFoundException;
import com.hcl.bank.model.AccountDetails;
import com.hcl.bank.model.BeneficiaryCompositeKey;
import com.hcl.bank.model.BeneficiaryDetails;

@Service
public class BeneficiaryServiceImpl implements BeneficiaryService
{
	@Autowired
	BeneficiaryRepository beneficiaryRepository;
	
	@Autowired
	BeneficiaryRequestDto beneficiaryRequestDto;
	
	@Autowired
	AccountRepository accountRepository;
	
	@Override
	public void saveBeneficiaryDetails(BeneficiaryRequestDto beneficiaryRequestDto) 
	{ 
		validateAccountNumber(beneficiaryRequestDto);
		
	     BeneficiaryDetails beneficiary=new BeneficiaryDetails();
	     BeneficiaryCompositeKey key=new BeneficiaryCompositeKey();
	     
	     key.setAccountNumber(beneficiaryRequestDto.getAccountNumber());
	     key.setBeneficiaryAccountNumber(beneficiaryRequestDto.getBeneficiaryAccountNumber());
	     
	     beneficiary.setKey(key);
	     beneficiary.setBeneficiaryName(beneficiaryRequestDto.getBeneficiaryName());
	     
	     beneficiaryRepository.save(beneficiary);
	}
	
	@Override
	public String validateAccountNumber(BeneficiaryRequestDto beneficiaryRequestDto) {
		AccountDetails account=accountRepository.findByaccountNumber(beneficiaryRequestDto.getBeneficiaryAccountNumber());
		if(account==null)
		{
			throw new CustomerNotFoundException("Invalid Account Number:" + beneficiaryRequestDto.getBeneficiaryAccountNumber());
		}
		return "Account Number is Valid";
	}
	
	
	/* Validating the beneficiaryAccountNumber */
	
	@Override
	public void validateBeneficiaryAccountNumber(String fromAccountNumber,String toAccountNumber)
	{
	
		BeneficiaryCompositeKey key=new BeneficiaryCompositeKey();
		key.setAccountNumber(fromAccountNumber);
		key.setBeneficiaryAccountNumber(toAccountNumber);
		
		
		Optional<BeneficiaryDetails> beneficiary=beneficiaryRepository.findById(key);
		if(!(beneficiary.isPresent())) 
			throw new BeneficiaryNotFoundException("Invalid  BeneficiaryAccountNumber:");
		
	}

}
