package com.hcl.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.bank.dao.AccountRepository;
import com.hcl.bank.dao.TransactionRepository;
import com.hcl.bank.dto.TransactionRequestDto;
import com.hcl.bank.exception.CustomerNotFoundException;
import com.hcl.bank.exception.InSufficientBalanceException;
import com.hcl.bank.model.AccountDetails;
import com.hcl.bank.model.TransactionDetails;

@Service
public class TransactionServiceImpl implements TransactionService
{
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	BeneficiaryService beneficiaryService;
		
	@Override
	public void saveTransactionDetails(TransactionRequestDto transactionRequestDto) 
	{
		//accountService.validateAccountNumber(transactionRequestDto);
		
		
		AccountDetails fromAccount=new AccountDetails();
		AccountDetails toAccount=new AccountDetails();
		
		fromAccount=accountRepository.findAccountByAccountNumber(transactionRequestDto.getFromAccountNumber());
		toAccount=accountRepository.findBalanceByAccountNumber(transactionRequestDto.getToAccountNumber());
		
		beneficiaryService.validateBeneficiaryAccountNumber(transactionRequestDto.getFromAccountNumber(),transactionRequestDto.getToAccountNumber() );
		
		if(fromAccount!=null && toAccount!=null) {

			if(fromAccount.getBalance()>transactionRequestDto.getAmount()) {
		
				
				 /* Setting the Transaction Details-1  */
		
		TransactionDetails transaction1=new TransactionDetails();
		
		transaction1.setAccountNumber(transactionRequestDto.getFromAccountNumber());
		transaction1.setAmount(transactionRequestDto.getAmount());
		double balanceAmount=fromAccount.getBalance()-transactionRequestDto.getAmount();
		fromAccount.setBalance(balanceAmount);
		accountRepository.save(fromAccount);
		transaction1.setTransactionType("DEBIT");
		transaction1.setDescription("The Amount is Debited");
		transactionRepository.save(transaction1);
		
		
		 /* Setting the Transaction Details-2  */
		
		TransactionDetails transaction2=new TransactionDetails();
		
		transaction2.setAccountNumber(transactionRequestDto.getToAccountNumber());
		transaction2.setAmount(transactionRequestDto.getAmount());
		double totalAmount=toAccount.getBalance()+transactionRequestDto.getAmount();
		toAccount.setBalance(totalAmount);
		accountRepository.save(toAccount);
		transaction2.setTransactionType("CREDIT");
		transaction2.setDescription("The Amount is Credited");
		transactionRepository.save(transaction2);
	}
			
			else 
			{
				throw new InSufficientBalanceException("Insufficient Balance");
			}
			
			}else 
			{
					 throw new CustomerNotFoundException("Account not found"); 
			}
	
	}
	
	
	

}
