package com.hcl.bank.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.bank.dao.BankRepository;
import com.hcl.bank.exception.InvalidLoginException;
import com.hcl.bank.helper.BankHelper;
import com.hcl.bank.model.Customer;

@Service
public class BankServiceImpl implements BankService 
{
	@Autowired
	BankRepository bankRepository;
	
	@Autowired
	AccountService accountService;

	@Override
	public Iterable<Customer> getAllCustomerDetails() 
	{
		return bankRepository.findAll(); 
	}

	
	@Override
	public void saveCustomer(Customer customer) 
	{
		customer.setId(BankHelper.generatecustomerID());
		bankRepository.save(customer);
		accountService.saveAccount(customer);
	}
	
	@Override
	public String validate(String emailID, String password) {
		String name = bankRepository.validateCustomer(emailID, password);
		if(name==null)
		{
			throw new InvalidLoginException("Invalid Login!!!");
		}
		return "login Successful... Welcome "+ name +" to the NetBanking.";
	}
	

}
