package com.hcl.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.bank.model.LoanDetails;
import com.hcl.bank.service.LoanService;

@RestController
public class LoanController {
	
	@Autowired
	LoanService loanService;
	
	@GetMapping("/loan") 
	public List<LoanDetails> getLoanId(@RequestParam("amount") double amount) 
	{
		List<LoanDetails> result=loanService.getLoanbyId(amount);
		return result;
	
	}

}
