package com.hcl.bank.service;

import com.hcl.bank.dto.BeneficiaryRequestDto;

public interface BeneficiaryService 
{
	public void saveBeneficiaryDetails(BeneficiaryRequestDto beneficiaryRequestDto);
	public void validateBeneficiaryAccountNumber(String fromAccountNumber,String toAccountNumber);

	public String validateAccountNumber(BeneficiaryRequestDto beneficiaryRequestDto);
}
