package com.hcl.bank.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.bank.model.AccountDetails;

@Repository
public interface AccountRepository extends CrudRepository<AccountDetails, String>
{
	public AccountDetails findByaccountNumber(String accountNumber);
	
	public AccountDetails findAccountByAccountNumber(String fromAccountNumber);
	public AccountDetails findBalanceByAccountNumber(String toAccountNumber);
	
	@Transactional
	@Modifying
    @Query("update AccountDetails a set a.balance=?1 where a.accountNumber='SBI1234567891'")
	int updateBalance(double balance);

	@Query("select balance from AccountDetails a where a.accountNumber='SBI1234567891'")
	public double getBalance();
	
}
