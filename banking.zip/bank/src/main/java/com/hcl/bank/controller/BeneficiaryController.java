package com.hcl.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.bank.dto.BeneficiaryRequestDto;
import com.hcl.bank.service.BeneficiaryService;

@RestController
public class BeneficiaryController 
{
	@Autowired
	BeneficiaryService beneficiaryService;
	
	@PostMapping("/beneficiary")
	public void saveBeneficiaryDetails(@RequestBody BeneficiaryRequestDto beneficiaryRequestDto)
	{
		beneficiaryService.saveBeneficiaryDetails(beneficiaryRequestDto);
	}

}
