package com.hcl.bank.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hcl.bank.exception.BeneficiaryNotFoundException;

public class BeneficiaryExceptionController extends ResponseEntityExceptionHandler 
{
	@ExceptionHandler(BeneficiaryNotFoundException.class)
	public ResponseEntity<Error> handleException(BeneficiaryNotFoundException exception)
	{
		Error error=new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimeStamp(LocalDateTime.now());
		error.setSuggestion("Please check your BeneficiaryAccountNumber");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	

}
