package com.hcl.bank.helper;

import java.util.ArrayList;
import java.util.List;

import com.hcl.bank.model.LoanDetails;

public class LoanHelper {
	
	public static List<LoanDetails> getAmount(double calculatedAmount,List<LoanDetails> loanDetails)
	{
		List<LoanDetails> list=new ArrayList<LoanDetails>();
		for(LoanDetails loan:loanDetails)
		{
			double rate=loan.getInterest()/12/100;
			double function=Math.pow((1+rate), (loan.getTenure()*12));
			double emi=((loan.getPrinciple()*rate*function))/(function-1);
			if(emi<calculatedAmount)
				list.add(loan);
		}
		return list;
		
	}

}
