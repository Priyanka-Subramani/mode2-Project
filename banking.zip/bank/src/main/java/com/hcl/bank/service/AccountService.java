package com.hcl.bank.service;

import com.hcl.bank.dto.TransactionRequestDto;
import com.hcl.bank.model.AccountDetails;
import com.hcl.bank.model.Customer;

public interface AccountService 
{
	public void saveAccount(Customer customer);
	
	public AccountDetails getAccount(long id);
	public AccountDetails getAccount(String accountNumber);
	
	public String validateAccountNumber(TransactionRequestDto transactionRequestDto);
	
	public int updateAmount(double balance);


}
