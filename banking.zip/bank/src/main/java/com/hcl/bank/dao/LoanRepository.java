package com.hcl.bank.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.bank.model.LoanDetails;

@Repository
public interface LoanRepository extends CrudRepository<LoanDetails, Integer> {

}
