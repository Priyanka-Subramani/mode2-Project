package com.hcl.bank.service;

import java.util.List;

import com.hcl.bank.model.LoanDetails;

public interface LoanService {
	
	public double calculateSimpleInterest(LoanDetails loan);
	
	public List<LoanDetails> getLoanbyId(double amount);
}
