package com.company.user.controller;

import java.sql.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.company.user.dto.FlightResponseDto;
import com.company.user.dto.TicketBookingRequestDto;
import com.company.user.dto.TicketBookingResponse;
import com.company.user.dto.TicketBookingResponseDto;

@RestController
public class GatewayController { 
	
	@Autowired
	RestTemplate restTemplate;
	
	private final Logger LOGGER=LoggerFactory.getLogger(UserController.class);
	
	
	
	@GetMapping("/flights/date")
	public ResponseEntity<List<FlightResponseDto>> searchFlights(@RequestParam(value="source") String source,@RequestParam(value="destination") String destination, @RequestParam(value="date") Date date) { 
		
		List<FlightResponseDto> list = restTemplate.getForEntity("http://FLIGHT/flight/flights/date?source="+source+"&destination="+destination+"&date="+date, List.class).getBody();
		return new ResponseEntity<List<FlightResponseDto>>(list,HttpStatus.OK);
	}
	
	
	@GetMapping("/flights/cost")
	public ResponseEntity<List<FlightResponseDto>> searchFlights(@RequestParam String source,@RequestParam String destination, @RequestParam  double economicCost) {
		
		List<FlightResponseDto> list = restTemplate.getForEntity("http://FLIGHT/flight/flights/cost?source="+source+"&destination="+destination+"&economicCost="+economicCost, List.class).getBody();
		return new ResponseEntity<List<FlightResponseDto>>(list,HttpStatus.OK);	
	}
	
	
	@GetMapping("/flights/flightName")
	public ResponseEntity<List<FlightResponseDto>> filterFlightByFlightName(@RequestParam String flightName) {
		
		List<FlightResponseDto> list = restTemplate.getForEntity("http://FLIGHT/flight/flights/flightName?flightName="+flightName, List.class).getBody();
		return new ResponseEntity<List<FlightResponseDto>>(list,HttpStatus.OK);	
	}
	
	
	@GetMapping("flights/{flightId}")
	public ResponseEntity<FlightResponseDto> getFlightByFlightId(@PathVariable String flightId) {
		
		FlightResponseDto flightResponse = restTemplate.getForEntity("http://FLIGHT/flight/flights/"+flightId,FlightResponseDto.class).getBody();
		return new ResponseEntity<FlightResponseDto>(flightResponse,HttpStatus.OK);
	}

	
	@GetMapping("flights/{id}/economicSeats")
	public ResponseEntity<Integer> updateEconomicSeats(@PathVariable String id,@RequestParam int economicSeats) {
		
		Integer updatedSeats = restTemplate.getForEntity("http://FLIGHT/flight/flights/"+id+"/economicSeats?economicSeats="+economicSeats,Integer.class).getBody();
		return new ResponseEntity<Integer>(updatedSeats,HttpStatus.OK);
		
	}
	
	@GetMapping("flights/{id}/businessSeats")
	public ResponseEntity<Integer> updateBusinessSeats(@PathVariable String id,@RequestParam int businessSeats) {
		
		Integer updatedSeats = restTemplate.getForEntity("http://FLIGHT/flight/flights/"+id+"/businessSeats?businessSeats="+businessSeats,Integer.class).getBody();
		return new ResponseEntity<Integer>(updatedSeats,HttpStatus.OK);
		
	}
	
	@PostMapping("/tickets")
    public ResponseEntity<TicketBookingResponseDto> registration(@RequestBody TicketBookingRequestDto ticketBookingRequestDto) {
		
		return restTemplate.postForEntity("http://TICKET/ticket/tickets", ticketBookingRequestDto, TicketBookingResponseDto.class);
	}
	
	
	@GetMapping("/tickets/{ticketId}") 
	public ResponseEntity<TicketBookingResponse> getTicketDetails(@PathVariable int ticketId) { 
		
		return restTemplate.getForEntity("http://TICKET/ticket/tickets/"+ticketId, TicketBookingResponse.class);			
	}


}
