package com.company.user.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.user.dto.FlightResponseDto;
import com.company.user.dto.UserRequestDto;
import com.company.user.dto.UserResponse;
import com.company.user.dto.UserResponseDto;
import com.company.user.service.UserService;

@RestController
public class UserController { 
	
	private final Logger LOGGER=LoggerFactory.getLogger(UserController.class);
	
	
	@Autowired
	UserService userService;
	
	
	
	@Autowired
	FlightResponseDto flightResponseDto;
	
	@PostMapping("/users")
	public ResponseEntity<UserResponseDto> registration(@RequestBody UserRequestDto userRequestDto) {
		LOGGER.info("Registration Part");
		return userService.saveUserDetails(userRequestDto);
	}
	
	@GetMapping("/users")
	public ResponseEntity<UserResponse> validation(@RequestParam long userId,@RequestParam String password) { 
		LOGGER.info("Validation Part");
		return userService.validateUser(userId, password);
		
	}
	
	
	
}
