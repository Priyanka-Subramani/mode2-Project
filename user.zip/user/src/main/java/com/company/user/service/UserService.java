package com.company.user.service;

import org.springframework.http.ResponseEntity;

import com.company.user.dto.UserRequestDto;
import com.company.user.dto.UserResponse;
import com.company.user.dto.UserResponseDto;


public interface UserService { 
	
	public ResponseEntity<UserResponseDto> saveUserDetails(UserRequestDto userRequestDto); 
		
	public ResponseEntity<UserResponse> validateUser(long userId, String password);
	
	
}
