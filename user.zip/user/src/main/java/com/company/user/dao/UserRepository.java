package com.company.user.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.user.model.User;



@Repository
public interface UserRepository extends CrudRepository<User, Long> { 
	
	public Optional<User> findByUserIdAndPassword(long userId, String password);

}
