package com.company.user.exception;

public class InvalidLoginCredentialsException extends RuntimeException { 
	
	private static final long serialVersionUID = 1L;
	
	public InvalidLoginCredentialsException(String message) {
		
		super(message);
	}

}
