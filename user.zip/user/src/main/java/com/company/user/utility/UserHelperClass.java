package com.company.user.utility;

import org.springframework.stereotype.Component;

import com.company.user.dto.UserRequestDto;

@Component
public class UserHelperClass {
	
	static long id=1230001;
	
	public static long generateUserId()
	{
		return id++;
	}
	
	public static String generatePassword(UserRequestDto userRequest) { 
		
		String name = userRequest.getName();
        
		if(name.length()<4) { 
			
			name+="#";
		}
		
		String subString = name.substring(0, 4);
        
		String upperCase = subString.toUpperCase();
		
		String password = upperCase + "@TRIVAGO123"; 
		
		return password;
		
	}

}
