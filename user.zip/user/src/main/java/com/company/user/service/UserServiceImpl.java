package com.company.user.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.company.user.dao.UserRepository;
import com.company.user.dto.UserRequestDto;
import com.company.user.dto.UserResponse;
import com.company.user.dto.UserResponseDto;
import com.company.user.exception.InvalidLoginCredentialsException;
import com.company.user.model.User;
import com.company.user.utility.UserHelperClass;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	private JavaMailSender javaMailSender;
	

	/*
	 *  User Details are taken and UserId and Password is generated
	 */
	
	@Override
	public ResponseEntity<UserResponseDto> saveUserDetails(UserRequestDto userRequestDto) {
		
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		User user = modelMapper.map(userRequestDto, User.class);
		user.setUserId(UserHelperClass.generateUserId());
		user.setPassword(UserHelperClass.generatePassword(userRequestDto));
		
		userRepository.save(user);
		
		SimpleMailMessage mail=new SimpleMailMessage();
		mail.setTo(userRequestDto.getEmailId());
		mail.setSubject("Welcome to Trivago Flight Booking Service");
		mail.setText("Hi "+userRequestDto.getName()+","+"\n" + "Your login credentials are "+"\n"+"UserId : "+user.getUserId()+"\n"+"Password : "+user.getPassword());
		
		javaMailSender.send(mail);
		
		
		String message="Successfully Registered";
		HttpStatus statusCode=HttpStatus.CREATED;
		UserResponseDto response= new UserResponseDto(statusCode.value(), message, user.getUserId(), user.getPassword());
		
		return new ResponseEntity<UserResponseDto>(response,HttpStatus.OK);
		
	}
	

	/*
	 * If UserId and Password is correct , Successfully logged in message is displayed
	 */
	
	@Override
	public ResponseEntity<UserResponse> validateUser(long userId, String password) {
		
		Optional<User> user = userRepository.findByUserIdAndPassword(userId, password);
		if(!(user.isPresent()))
			throw new InvalidLoginCredentialsException("Invalid Login Credentials!");
		
		String message="Successfully Logged In";
		HttpStatus statusCode=HttpStatus.OK;
		UserResponse response = new UserResponse(statusCode.value(), message);
		return new ResponseEntity<UserResponse>(response, HttpStatus.OK);
	}
	
}
