package com.company.user.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.company.user.exception.InvalidLoginCredentialsException;


@ControllerAdvice
public class InvalidLoginCredentialsExceptionController extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(InvalidLoginCredentialsException.class)
	public ResponseEntity<Error> handleException(InvalidLoginCredentialsException exception) {
		
		Error error=new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimeStamp(LocalDateTime.now());
		error.setSuggestion("Please retry with correct UserId and Password");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}

}
