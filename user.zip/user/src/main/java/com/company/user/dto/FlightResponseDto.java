package com.company.user.dto;

import java.sql.Date;
import java.sql.Time;

import org.springframework.stereotype.Component;

@Component
public class FlightResponseDto {
	
	private String flightId;
	private String flightName;
	private String type;
	private String source;
	private String destination;
	private Date date;
	private Time departureTime;
	private Time arrivalTime;
	private int businessSeats;
	private double businessCost;
	private int economicSeats;
	private double economicCost;
	
	/*
	public FlightResponseDto(String flightId, String flightName, String type, String source, String destination,
			Date date, Time departureTime, Time arrivalTime, int businessSeats, double businessCost, int economicSeats,
			double economicCost) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.type = type;
		this.source = source;
		this.destination = destination;
		this.date = date;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.businessSeats = businessSeats;
		this.businessCost = businessCost;
		this.economicSeats = economicSeats;
		this.economicCost = economicCost;
	}
	*/
	
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}
	public Time getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public int getBusinessSeats() {
		return businessSeats;
	}
	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}
	public double getBusinessCost() {
		return businessCost;
	}
	public void setBusinessCost(double businessCost) {
		this.businessCost = businessCost;
	}
	public int getEconomicSeats() {
		return economicSeats;
	}
	public void setEconomicSeats(int economicSeats) {
		this.economicSeats = economicSeats;
	}
	public double getEconomicCost() {
		return economicCost;
	}
	public void setEconomicCost(double economicCost) {
		this.economicCost = economicCost;
	}
	
	
	

}

