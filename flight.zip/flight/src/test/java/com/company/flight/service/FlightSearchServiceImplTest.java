package com.company.flight.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.company.flight.dao.FlightRepository;
import com.company.flight.dto.FlightResponseDto;
import com.company.flight.exception.FlightNotFoundException;
import com.company.flight.model.Category;
import com.company.flight.model.Flight;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FlightSearchServiceImplTest { 
	
	@InjectMocks
	FlightSearchServiceImpl flightSearchServiceImpl;
	
	@Mock
	FlightRepository flightRepository;
	
	static Flight flight = new Flight();
	static List<Flight> flightList = new ArrayList<Flight>();
	
	@BeforeClass
	public static void setup(){
		flight.setSource("bangalore");
		flight.setDestination("chennai");
		flight.setDate(Date.valueOf("2019-12-06"));
		flightList.add(flight);
	}
	
	/*
	 * public User findById(Integer id) throws NullPointerException { Optional<User>
	 * users = userRepository.findById(id); }
	 * 
	 * 
	 * @Override public List<FlightResponseDto> getFlights(String source,String
	 * destination,Date date) {
	 * 
	 * flightResponseList.clear();
	 * 
	 * flightList= flightRepository.findBySourceAndDestinationAndDate(source,
	 * destination, date);
	 * 
	 * if(flightList.isEmpty()) throw new
	 * FlightNotFoundException("No Flights Available!");
	 * flightResponseList=flightList.stream().map(flight->searchFlights(flight)).
	 * collect(Collectors.toList());
	 * 
	 * return flightResponseList;
	 * 
	 * }
	 */
	
	/*
	 * @Test public void testGetFlights() {
	 * 
	 * Mockito.when(flightRepository.findById(Mockito.anyString())).thenReturn(
	 * Optional.of(flight)); List<Flight> flightList =
	 * flightSearchServiceImpl.getFlights("bangalore", "chennai",
	 * Date.valueOf("2019-12-06"));
	 * 
	 * }
	 */

}
