package com.company.flight.service;

import java.util.List;

import com.company.flight.model.Category;
import com.company.flight.model.Flight;

public interface CategoryService {
	
	public List<Category> getAllCategoryDetails(List<Flight> flightList);
	
	/*
	 * public int getNumberOfEconomicSeatsByflightId(String flightId);
	 * 
	 * public int getNumberOfBusinessSeatsByflightId(String flightId);
	 */
	
	public int updateEconomicSeats(int economicSeats,String id);
	
	public int updateBusinessSeats(int businessSeats,String id);
}
