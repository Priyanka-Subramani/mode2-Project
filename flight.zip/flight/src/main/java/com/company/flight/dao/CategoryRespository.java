package com.company.flight.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.flight.model.Category;

@Repository
public interface CategoryRespository extends CrudRepository<Category, String> { 
	
	
	@Transactional
	@Modifying
    @Query("update Category c set c.economicSeats=?1 where c.id=?2")
	int updateEconomicSeats(int economicSeats, String id);
	
	@Transactional
	@Modifying
    @Query("update Category c set c.businessSeats=?1 where c.id=?2")
	int updateBusinessSeats(int businessSeats, String id);


}
