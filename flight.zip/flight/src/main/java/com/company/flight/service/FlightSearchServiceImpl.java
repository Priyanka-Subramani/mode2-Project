package com.company.flight.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.flight.dao.CategoryRespository;
import com.company.flight.dao.FlightRepository;
import com.company.flight.dto.FlightResponseDto;
import com.company.flight.exception.FlightNotFoundException;
import com.company.flight.model.Category;
import com.company.flight.model.Flight;

@Service
public class FlightSearchServiceImpl implements FlightSearchService {
	
	@Autowired
	FlightRepository flightRepository;
	
	@Autowired
	CategoryRespository categoryRespository;
	
	@Autowired
	CategoryService categoryService;
	
	@Autowired
	ModelMapper modelMapper;
	
	
	List<Flight> flightList = new ArrayList<Flight>();
	List<FlightResponseDto> flightResponseList = new ArrayList<>();
	
	
	
	/*
	 * Flights are searching by Source and Destination and Date. 
	 * If the Flight is available then the Flight Details are displayed.
	 */
	
	public FlightResponseDto searchFlights(Flight flight) {
		
		List<Category> categoryList = categoryService.getAllCategoryDetails(flightList);
		
			FlightResponseDto flightResponse = modelMapper.map(flight, FlightResponseDto.class);
			
			for(Category category : categoryList) { 
				
				if(flight.getFlightId().equalsIgnoreCase(category.getId())) {
				
				flightResponse.setEconomicSeats(category.getEconomicSeats());
				flightResponse.setEconomicCost(category.getEconomicCost());
			    flightResponse.setBusinessSeats(category.getBusinessSeats());
			    flightResponse.setBusinessCost(category.getBusinessCost());
				
			}
		}
		return flightResponse;
			
	
	}
	
	@Override
	public List<FlightResponseDto> getFlights(String source,String destination,Date date) {
		
		 flightResponseList.clear();
			
			flightList= flightRepository.findBySourceAndDestinationAndDate(source, destination, date);
			
			if(flightList.isEmpty())
				throw new FlightNotFoundException("No Flights Available!");
			flightResponseList=flightList.stream().map(flight->searchFlights(flight)).collect(Collectors.toList());
			
		return flightResponseList;
		 
	}
	
	/*
	 * Flights are searching by Source and Destination and Cost. 
	 * If the Flight is available then the Flight Details are displayed.
	 */
	
	@Override
	public List<FlightResponseDto> getFlights(String source, String destination, double economicCost) {
		
		flightResponseList.clear();
		
		flightList = flightRepository.getFlights(source, destination, economicCost);
			
		if(flightList.isEmpty())
			throw new FlightNotFoundException("No Flights Available!");
		flightResponseList=flightList.stream().map(flight->searchFlights(flight)).collect(Collectors.toList());	
			
	return flightResponseList; 
	}
	
	/*
	 * Flights are filtering by Source and Destination and Date and FlightName. 
	 * If the Flight is available then the Flight Details are displayed.
	 */
	
	@Override
	public List<FlightResponseDto> getFlights(String flightName) {
		
		List<FlightResponseDto> flightsList=flightResponseList.stream().filter(flight1->flight1.getFlightName().equalsIgnoreCase(flightName)).collect(Collectors.toList());
		if(flightsList.isEmpty())
			throw new FlightNotFoundException("No Flights Available!");
		return flightsList; 
	}

	
	@Override
	public List<FlightResponseDto> getFlightByflightId(String flightId) {
		
		flightList = flightRepository.findByFlightId(flightId);
		if(!(flightList.isEmpty()))
		flightResponseList = flightList.stream().map(flight->searchFlights(flight)).collect(Collectors.toList());
		return flightResponseList;
	}

	
	@Override
	public FlightResponseDto searchFlightByflightId(String flightId) { 
				
	    Optional<Flight> flight = flightRepository.findById(flightId);
	    Optional<Category> category = categoryRespository.findById(flightId);
	    
	    FlightResponseDto flightResponse = modelMapper.map(flight.get(), FlightResponseDto.class); 
	    
	    flightResponse.setEconomicSeats(category.get().getEconomicSeats());
	    flightResponse.setEconomicCost(category.get().getEconomicCost());
	    flightResponse.setBusinessSeats(category.get().getBusinessSeats());
	    flightResponse.setBusinessCost(category.get().getBusinessCost());
	    
	    return flightResponse;
	
	}
}
