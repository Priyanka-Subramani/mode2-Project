package com.company.flight.service;

import java.sql.Date;
import java.util.List;

import com.company.flight.dto.FlightResponseDto;

public interface FlightSearchService {
	
	
	public List<FlightResponseDto> getFlights(String source,String destination,Date date);
	
	public List<FlightResponseDto> getFlights(String source,String destination,double economicCost);
	
	public List<FlightResponseDto> getFlights(String flightName);
	
	public List<FlightResponseDto> getFlightByflightId(String flightId); 
	
	public FlightResponseDto searchFlightByflightId(String flightId);
}
