package com.company.flight.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.flight.model.Category;
import com.company.flight.service.CategoryService;

@RestController
public class CategorySearchController {
	
	@Autowired
	CategoryService categoryService;
	
	
	@GetMapping("flights/{id}/economicSeats")
	public ResponseEntity<Integer> updateEconomicSeats(@PathVariable String id,@RequestParam int economicSeats) {
		
		Integer seats = categoryService.updateEconomicSeats(economicSeats, id);
		return new ResponseEntity<Integer>(seats,HttpStatus.OK);
		
	}
	
	@GetMapping("flights/{id}/businessSeats")
	public ResponseEntity<Integer> updateBusinessSeats(@PathVariable String id,@RequestParam int businessSeats) {
		
		Integer seats = categoryService.updateBusinessSeats(businessSeats, id);
		return new ResponseEntity<Integer>(seats,HttpStatus.OK);
		
	}
	

}
