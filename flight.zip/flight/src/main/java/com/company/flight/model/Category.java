package com.company.flight.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Category {
	
	@Id
	private String id;
	private int businessSeats;
	private double businessCost;
	private int economicSeats;
	private double economicCost;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getBusinessSeats() {
		return businessSeats;
	}
	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}
	public double getBusinessCost() {
		return businessCost;
	}
	public void setBusinessCost(double businessCost) {
		this.businessCost = businessCost;
	}
	public int getEconomicSeats() {
		return economicSeats;
	}
	public void setEconomicSeats(int economicSeats) {
		this.economicSeats = economicSeats;
	}
	public double getEconomicCost() {
		return economicCost;
	}
	public void setEconomicCost(double economicCost) {
		this.economicCost = economicCost;
	}
	
	
	

}
