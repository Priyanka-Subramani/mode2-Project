package com.company.flight.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.flight.dto.FlightResponseDto;
import com.company.flight.service.FlightSearchService;

@RestController
public class FlightSearchController {
	
	@Autowired
	FlightSearchService flightSearchService;
	
	
	@GetMapping("/flights/date")
	public ResponseEntity<List<FlightResponseDto>> searchFlights(@RequestParam(value="source") String source,@RequestParam(value="destination") String destination, @RequestParam(value="date") Date date) { 
		
		List<FlightResponseDto> flightResponseList = flightSearchService.getFlights(source, destination, date);
		return new ResponseEntity<List<FlightResponseDto>>(flightResponseList,HttpStatus.OK);
	}
	
	@GetMapping("/flights/cost")
	public ResponseEntity<List<FlightResponseDto>> searchFlights(@RequestParam String source,@RequestParam String destination, @RequestParam  double economicCost) {
		
		List<FlightResponseDto> flightResponseList = flightSearchService.getFlights(source, destination, economicCost);
		return new ResponseEntity<List<FlightResponseDto>>(flightResponseList,HttpStatus.OK);
		
	}
	
	@GetMapping("/flights/flightName")
	public ResponseEntity<List<FlightResponseDto>> filterFlightByFlightName(@RequestParam String flightName) {
		
		List<FlightResponseDto> flightResponseList = flightSearchService.getFlights(flightName);
		return new ResponseEntity<List<FlightResponseDto>>(flightResponseList,HttpStatus.OK);
	}
	
	
	@GetMapping("flights/{flightId}")
	public ResponseEntity<FlightResponseDto> getFlightByFlightId(@PathVariable String flightId) {
		
		FlightResponseDto flightResponse = flightSearchService.searchFlightByflightId(flightId);
		return new ResponseEntity<FlightResponseDto>(flightResponse,HttpStatus.OK);
	}

}
