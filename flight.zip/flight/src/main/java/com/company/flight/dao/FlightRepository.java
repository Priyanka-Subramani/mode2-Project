package com.company.flight.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.flight.model.Flight;

@Repository
public interface FlightRepository extends CrudRepository<Flight, String> {  
	
	List<Flight> findBySourceAndDestinationAndDate(String source,String destination,Date date); 
	
	
	@Query("select f from Flight f,Category c where f.source=?1 and f.destination=?2 and c.economicCost<=?3 and f.flightId=c.id ")
	List<Flight> getFlights(String source,String destination,double economicCost);
	
	public List<Flight> findByFlightId(String flightId);
}
