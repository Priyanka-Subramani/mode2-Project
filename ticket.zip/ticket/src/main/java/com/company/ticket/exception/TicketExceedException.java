package com.company.ticket.exception;

public class TicketExceedException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public TicketExceedException(String message) {
		super(message);
	}
	
	

}
