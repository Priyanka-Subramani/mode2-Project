package com.company.ticket.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.company.ticket.dto.TicketBookingRequestDto;
import com.company.ticket.dto.TicketBookingResponse;
import com.company.ticket.dto.TicketBookingResponseDto;
import com.company.ticket.service.TicketBookingService;

@RestController
public class TicketBookingController { 
	
	@Autowired
	TicketBookingService ticketBookingService;
	
	@PostMapping("/tickets")
    public ResponseEntity<TicketBookingResponseDto> registration(@RequestBody TicketBookingRequestDto ticketBookingRequestDto) {
		
		return ticketBookingService.saveTicketDetails(ticketBookingRequestDto);
	}
	
	@GetMapping("/tickets/{ticketId}") 
	public ResponseEntity<TicketBookingResponse> getTicketDetails(@PathVariable int ticketId) { 
		
		TicketBookingResponse response = ticketBookingService.getTicketDetails(ticketId);
		return new ResponseEntity<TicketBookingResponse>(response,HttpStatus.OK);
		
	}

}
