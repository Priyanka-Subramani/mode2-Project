package com.company.ticket.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class PassengerTicketKey implements Serializable { 
	
	private static final long serialVersionUID = 1L;
	private int passengerId;
	private int ticketId;
	
	
	public int getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	
	

}
