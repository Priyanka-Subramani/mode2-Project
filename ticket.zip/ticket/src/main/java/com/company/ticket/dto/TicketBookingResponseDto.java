package com.company.ticket.dto;

public class TicketBookingResponseDto {
	
	private long ticketId;
	private int statusCode;
	private String message;
	
	public TicketBookingResponseDto(long ticketId, int statusCode, String message) {
		super();
		this.ticketId = ticketId;
		this.statusCode = statusCode;
		this.message = message;
	}
	
	
	public long getTicketId() {
		return ticketId;
	}
	public void setTicketId(long ticketId) {
		this.ticketId = ticketId;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	

}
