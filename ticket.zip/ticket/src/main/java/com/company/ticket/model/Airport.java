package com.company.ticket.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Airport {
	
	@Id
	private String airportId;
	private String name;
	private String location;
	
	public String getAirportId() {
		return airportId;
	}
	public void setAirportId(String airportId) {
		this.airportId = airportId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

}
