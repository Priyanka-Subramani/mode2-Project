package com.company.ticket.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.ticket.model.Ticket;

@Repository
public interface TicketRepository extends CrudRepository<Ticket, Integer> { 
	
	Ticket findByTicketId(int ticketId);

}
