package com.company.ticket.service;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.company.ticket.dao.PassengerRepository;
import com.company.ticket.dao.TicketRepository;
import com.company.ticket.dto.FlightResponseDto;
import com.company.ticket.dto.PassengerRequestDto;
import com.company.ticket.dto.TicketBookingRequestDto;
import com.company.ticket.dto.TicketBookingResponse;
import com.company.ticket.dto.TicketBookingResponseDto;
import com.company.ticket.exception.SeatsNotAvailableException;
import com.company.ticket.exception.TicketExceedException;
import com.company.ticket.model.Passenger;
import com.company.ticket.model.PassengerTicketKey;
import com.company.ticket.model.Ticket;
import com.company.ticket.utility.TicketHelperClass;


@Service
public class TicketBookingServiceImpl implements TicketBookingService {
	
	@Autowired
	TicketRepository ticketRepository;
	
	@Autowired
	PassengerRepository passengerRepository;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	RestTemplate restTemplate;
	
	
	Ticket ticket = new Ticket();
	Passenger passenger= new Passenger();
	PassengerTicketKey key = new PassengerTicketKey();
	
	
	@Override
	public ResponseEntity<TicketBookingResponseDto> saveTicketDetails(TicketBookingRequestDto ticketBookingRequestDto) {
		
		
		List<PassengerRequestDto> passengerList = ticketBookingRequestDto.getPassengerRequestDto();
		
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		/*
		FlightResponseDto[] flightResponselists = restTemplate.getForEntity("http://localhost:8084/flight/flights/"+ticketBookingRequestDto.getFlightId(),FlightResponseDto[].class).getBody();
		List<FlightResponseDto> flightResponselist =  new ArrayList<FlightResponseDto>();
		Stream.of(flightResponselists).forEach(flight -> flightResponselist.add(flight));	
		*/
		FlightResponseDto flightResponselist = restTemplate.getForEntity("http://FLIGHT/flight/flights/"+ticketBookingRequestDto.getFlightId(),FlightResponseDto.class).getBody();
		
		if(passengerList.size()<=3) {
			
			
			if((flightResponselist.getEconomicSeats() >= passengerList.size()) && (flightResponselist.getBusinessSeats() >= passengerList.size())) {
				
			ticket = modelMapper.map(ticketBookingRequestDto, Ticket.class);
			ticket.setTicketId(TicketHelperClass.generateTicketId());
			ticket.setSeats(passengerList.size());
			ticketRepository.save(ticket);
			
			for(PassengerRequestDto list : passengerList) {
					
				passenger = modelMapper.map(list, Passenger.class);
				key.setTicketId(ticket.getTicketId());
				key.setPassengerId(TicketHelperClass.generatePassengerId());
				passenger.setKey(key);
				
				passengerRepository.save(passenger);
					
				
			}
		}
			else
				throw new SeatsNotAvailableException("Seats not available!");
		}
		else 
			throw new TicketExceedException("Passenger count is high!");
		
		if(ticketBookingRequestDto.getCategory().equalsIgnoreCase("economic")) { 
			
			Integer updatedSeats =flightResponselist.getEconomicSeats() - passengerList.size();
			restTemplate.getForEntity("http://FLIGHT/flight/flights/"+ticketBookingRequestDto.getFlightId()+"/economicSeats?economicSeats="+updatedSeats,Integer.class).getBody();
			
			double cost = flightResponselist.getEconomicCost() * passengerList.size();
			restTemplate.getForEntity("http://BANK/bank/bank/balance?balance="+ cost, Integer.class).getBody();
			System.out.println(cost);
		}
		else { 
			
			Integer updatedSeats = flightResponselist.getBusinessSeats() - passengerList.size();
			restTemplate.getForEntity("http://FLIGHT/flight/flights/"+ticketBookingRequestDto.getFlightId()+"/businessSeats?businessSeats="+updatedSeats,Integer.class).getBody();
			
			double cost = flightResponselist.getBusinessCost() * passengerList.size();
			restTemplate.getForEntity("http://BANK/bank/bank/balance?balance="+ cost, Integer.class).getBody();

		}
		
		
		String message="Flight Ticket Booked Successfully";
		HttpStatus statusCode=HttpStatus.CREATED;
		TicketBookingResponseDto response= new TicketBookingResponseDto(ticket.getTicketId(), statusCode.value(), message);
		
		return new ResponseEntity<TicketBookingResponseDto>(response,HttpStatus.OK);
	}
		

	@Override
	public TicketBookingResponse getTicketDetails(int ticketId) { 
		
		ticket = ticketRepository.findByTicketId(ticketId); 
		System.out.println(ticket.getFlightId());
		/*
		FlightResponseDto[] flightResponselists = restTemplate.getForEntity("http://localhost:8084/flight/flights/"+ticket.getFlightId(),FlightResponseDto[].class).getBody();
		List<FlightResponseDto> flightResponselist =  new ArrayList<FlightResponseDto>();
		Stream.of(flightResponselists).forEach(flight -> flightResponselist.add(flight));	
		*/
		
		FlightResponseDto flightResponselist = restTemplate.getForEntity("http://FLIGHT/flight/flights/"+ticket.getFlightId(),FlightResponseDto.class).getBody();
		
		TicketBookingResponse ticketBookingResponse = new TicketBookingResponse();
		
		ticketBookingResponse.setTicketId(ticketId);
		ticketBookingResponse.setFlightId(flightResponselist.getFlightId());
		ticketBookingResponse.setFlightName(flightResponselist.getFlightName());
		ticketBookingResponse.setAirporId(ticket.getAirportId());
		ticketBookingResponse.setDate(flightResponselist.getDate());
		ticketBookingResponse.setSource(flightResponselist.getSource());
		ticketBookingResponse.setDestination(flightResponselist.getDestination());
		ticketBookingResponse.setDepartureTime(flightResponselist.getDepartureTime());
		ticketBookingResponse.setArrivalTime(flightResponselist.getArrivalTime());
		
		return ticketBookingResponse;
	}
		
}
