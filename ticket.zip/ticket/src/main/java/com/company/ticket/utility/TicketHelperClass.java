package com.company.ticket.utility;

public class TicketHelperClass { 
	
	static int id=100;
	static int passengerId=1;
	
	public static int generateTicketId() {
		return id++;
	}
	
	public static int generatePassengerId() {
		return passengerId++;
	}

}
