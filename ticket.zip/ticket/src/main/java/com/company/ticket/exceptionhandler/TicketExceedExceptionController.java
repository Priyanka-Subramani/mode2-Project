package com.company.ticket.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


import com.company.ticket.exception.TicketExceedException;

@ControllerAdvice
public class TicketExceedExceptionController extends ResponseEntityExceptionHandler { 
	
	@ExceptionHandler(TicketExceedException.class)
	public ResponseEntity<Error> handleException(TicketExceedException exception) {
		
		Error error=new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimeStamp(LocalDateTime.now());
		error.setSuggestion("You can book tickets only for 3 passengers...");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}

}
