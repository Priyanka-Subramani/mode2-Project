package com.company.ticket.dto;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Component;


@Component
public class TicketBookingRequestDto { 
	
	private long userId;
	private String airportId;
	private String flightId;
	private String category;
	private Date date;
	private List<PassengerRequestDto> passengerRequestDto;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getAirportId() {
		return airportId;
	}
	public void setAirportId(String airportId) {
		this.airportId = airportId;
	}
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	public List<PassengerRequestDto> getPassengerRequestDto() {
		return passengerRequestDto;
	}
	public void setPassengerRequestDto(List<PassengerRequestDto> passengerRequestDto) {
		this.passengerRequestDto = passengerRequestDto;
	}
	
	

}
