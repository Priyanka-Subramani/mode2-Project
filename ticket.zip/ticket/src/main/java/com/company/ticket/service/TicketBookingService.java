package com.company.ticket.service;

import org.springframework.http.ResponseEntity;

import com.company.ticket.dto.TicketBookingRequestDto;
import com.company.ticket.dto.TicketBookingResponse;
import com.company.ticket.dto.TicketBookingResponseDto;

public interface TicketBookingService {
	
	public ResponseEntity<TicketBookingResponseDto> saveTicketDetails(TicketBookingRequestDto ticketBookingRequestDto);

	public TicketBookingResponse getTicketDetails(int ticketId);
}
